# Stocklist

Parts inventory linked to SQL Account, running on Supabase.

- `index.html` – landing page
- `app.html` – the inventory app (sign in, parts, movements, POs/DOs, adjustments, cycle counts, team)

Both are static files: host them on any static host (GitHub Pages, Netlify, your own server).
The app talks to Supabase project `zvtfphoprzxhpzakkhqb` with its publishable key; access is controlled by
row-level security and each user's role (admin, store keeper, purchasing, viewer).

After hosting, add the site's address in Supabase → Authentication → URL Configuration
(Site URL and Redirect URLs) so sign-up confirmation and password-reset emails return to the app.
